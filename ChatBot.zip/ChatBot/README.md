# ChatBot
A simple Chatbot App using AIML. For tutorial please visit : https://medium.com/@harivigneshjayapalan/android-baking-a-simple-chatbot-in-30-minutes-aiml-ff43c3269025#.b29g2dqgw
